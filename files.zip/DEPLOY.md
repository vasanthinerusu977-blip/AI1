# AI Bias Metrics Dashboard — Deployment Guide

## Option A: GitHub Pages (free, ~2 minutes)

1. Go to https://github.com/new
2. Create a new repository — name it anything (e.g. `ai-bias-dashboard`)
3. Set visibility to **Public**
4. Click **Create repository**
5. Upload `index.html` via the "Add file → Upload files" button
6. Go to **Settings → Pages**
7. Under "Source", select **Deploy from a branch**
8. Set branch to `main`, folder to `/ (root)` — click **Save**
9. Wait ~60 seconds, then visit:
   `https://YOUR-USERNAME.github.io/ai-bias-dashboard/`

Your dashboard is now live at that URL.

---

## Option B: Netlify Drop (free, 30 seconds)

1. Go to https://app.netlify.com/drop
2. Drag and drop the `index.html` file onto the page
3. Netlify instantly gives you a live URL like:
   `https://random-name-123.netlify.app`
4. Optional: click "Site settings → Change site name" to customise the URL

---

## Option C: Vercel (free, ~2 minutes)

1. Go to https://vercel.com/new
2. Choose "Browse" and upload a folder containing just `index.html`
3. Click **Deploy**
4. Your live URL will be:
   `https://your-project.vercel.app`

---

## Notes

- No build step or dependencies needed — it's a single self-contained HTML file
- Chart.js is loaded from CDN (cdnjs.cloudflare.com) — requires internet connection
- Works on all modern browsers (Chrome, Firefox, Safari, Edge)
- Fully responsive — works on mobile
- To update the dashboard, simply re-upload the `index.html` file
